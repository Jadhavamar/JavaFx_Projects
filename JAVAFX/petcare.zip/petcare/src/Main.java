import javafx.application.Application;
import view.pethome;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello World");
        Application.launch(pethome.class, args);

    }
}